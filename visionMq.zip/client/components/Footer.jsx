import React from 'react';

const Footer = () => {
  
  return (
    <div id='footer'>
      <p id='res'>VisionMQ ® 2023</p>
    </div>
  )
}

export default Footer;