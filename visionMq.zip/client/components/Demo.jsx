import React from 'react';

const Demo = () => {

  return (
    <div id='demo'>
     <div id='demo-content'>
      <h2>Demo</h2>
      </div>
    </div>
  );
};

export default Demo;