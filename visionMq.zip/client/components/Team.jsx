import React from 'react';

const Team = () => {

  return (
    <div id='team'>
      <div id='team-content'>
      <h2>Team</h2>
      </div>
    </div>
  );
};

export default Team;